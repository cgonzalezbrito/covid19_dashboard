Master contains four files:
- Covid_ec : contains the number of people positive for COVID by canton/province
- age range alive_deads: contains the range of alive/deaths by age range + PROBABLY dead
- Positive age range: contains the gender which reported positive for COVID organized by age range
- deaths by province

Files: age range and covid_ec might not have simultaneously updates due to delays on source

Sources:
1. Secretaria nacional de gestion de riesgos @riesgos_ec 
2. Ministerio de Salud Publica 

csv file from official reports for COVID19 in Ecuador
from 13 - mar - 2020 to: (last update)

